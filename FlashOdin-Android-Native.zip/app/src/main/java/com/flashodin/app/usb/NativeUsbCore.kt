package com.flashodin.app.usb

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.nio.ByteBuffer
import java.nio.ByteOrder

enum class DetectedProtocol {
    ODIN,
    ADB,
    FASTBOOT,
    MTP_ONLY,
    UNKNOWN
}

data class UsbBinding(
    val device: UsbDevice,
    val connection: UsbDeviceConnection,
    val protocol: DetectedProtocol,
    val dataInterface: UsbInterface,
    val controlInterface: UsbInterface?,
    val epIn: UsbEndpoint,
    val epOut: UsbEndpoint
) {
    fun close() {
        try {
            controlInterface?.let { connection.releaseInterface(it) }
            connection.releaseInterface(dataInterface)
            connection.close()
        } catch (_: Exception) {
        }
    }
}

object NativeUsbCore {
    const val SAMSUNG_VID = 0x04E8
    private val SAMSUNG_DOWNLOAD_PIDS = setOf(0x685D, 0x6601, 0x68C3, 0x68A9)

    private const val ADB_CLASS = 0xFF
    private const val ADB_SUBCLASS = 0x42
    private const val ADB_PROTOCOL = 0x01
    private const val FASTBOOT_PROTOCOL = 0x03

    private const val CDC_CTRL_CLASS = 0x02
    private const val CDC_DATA_CLASS = 0x0A

    fun listAttachedDevices(usbManager: UsbManager): List<UsbDevice> {
        return usbManager.deviceList.values.toList()
    }

    fun detectProtocol(device: UsbDevice): DetectedProtocol {
        var hasAdb = false
        var hasFastboot = false
        var hasCdc = false
        var hasMtp = false

        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)
            if (iface.interfaceClass == ADB_CLASS && iface.interfaceSubclass == ADB_SUBCLASS) {
                if (iface.interfaceProtocol == FASTBOOT_PROTOCOL) hasFastboot = true
                if (iface.interfaceProtocol == ADB_PROTOCOL) hasAdb = true
            }
            if (iface.interfaceClass == CDC_DATA_CLASS || iface.interfaceClass == CDC_CTRL_CLASS) {
                hasCdc = true
            }
            if (iface.interfaceClass == 0x06 || iface.interfaceClass == 0x08) {
                hasMtp = true
            }
        }

        val isSamsung = device.vendorId == SAMSUNG_VID
        val isSamsungDlPid = isSamsung && device.productId in SAMSUNG_DOWNLOAD_PIDS

        return when {
            hasFastboot -> DetectedProtocol.FASTBOOT
            isSamsungDlPid || (isSamsung && hasCdc && !hasAdb && !hasMtp) -> DetectedProtocol.ODIN
            hasAdb -> DetectedProtocol.ADB
            isSamsung && hasCdc -> DetectedProtocol.ODIN
            hasMtp -> DetectedProtocol.MTP_ONLY
            else -> DetectedProtocol.UNKNOWN
        }
    }

    fun describeDevice(device: UsbDevice): String {
        val vidHex = "0x%04X".format(device.vendorId)
        val pidHex = "0x%04X".format(device.productId)
        val name = device.productName ?: device.manufacturerName ?: "USB Device"
        return "$name ($vidHex:$pidHex)"
    }

    /**
     * Opens the USB device via Android UsbManager, force-claims interfaces (detaching kernel drivers),
     * and sends Samsung CDC-ACM Line Coding + DTR/RTS when binding Odin.
     */
    fun bindDevice(
        usbManager: UsbManager,
        device: UsbDevice,
        onLog: (String) -> Unit
    ): UsbBinding {
        val protocol = detectProtocol(device)
        onLog("تشخیص خودکار هسته نیتیو: $protocol — ${describeDevice(device)}")

        if (protocol == DetectedProtocol.MTP_ONLY) {
            throw IllegalStateException(
                "کابل OTG سالم است و گوشی شناسایی شد، اما فقط در حالت MTP است. برای فلش وارد Download/Fastboot Mode شوید یا USB Debugging را روشن کنید."
            )
        }

        val conn = usbManager.openDevice(device)
            ?: throw IllegalStateException("دسترسی به پورت USB صادر نشد. مجوز USB را تایید کنید.")

        var ctrlIface: UsbInterface? = null
        var dataIface: UsbInterface? = null
        var epIn: UsbEndpoint? = null
        var epOut: UsbEndpoint? = null

        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)
            val matchesTarget = when (protocol) {
                DetectedProtocol.FASTBOOT ->
                    iface.interfaceClass == ADB_CLASS &&
                        iface.interfaceSubclass == ADB_SUBCLASS &&
                        iface.interfaceProtocol == FASTBOOT_PROTOCOL

                DetectedProtocol.ADB ->
                    iface.interfaceClass == ADB_CLASS &&
                        iface.interfaceSubclass == ADB_SUBCLASS &&
                        iface.interfaceProtocol == ADB_PROTOCOL

                DetectedProtocol.ODIN -> {
                    if (iface.interfaceClass == CDC_CTRL_CLASS && ctrlIface == null) {
                        ctrlIface = iface
                    }
                    iface.interfaceClass == CDC_DATA_CLASS
                }

                else -> true
            }

            if (matchesTarget && dataIface == null) {
                val (inEp, outEp) = findBulkEndpoints(iface)
                if (inEp != null && outEp != null) {
                    dataIface = iface
                    epIn = inEp
                    epOut = outEp
                }
            }
        }

        // Fallback: any interface with Bulk IN + Bulk OUT
        if (dataIface == null) {
            for (i in 0 until device.interfaceCount) {
                val iface = device.getInterface(i)
                val (inEp, outEp) = findBulkEndpoints(iface)
                if (inEp != null && outEp != null) {
                    dataIface = iface
                    epIn = inEp
                    epOut = outEp
                    break
                }
            }
        }

        if (dataIface == null || epIn == null || epOut == null) {
            conn.close()
            throw IllegalStateException("کانال Bulk IN/OUT روی دستگاه یافت نشد.")
        }

        // Force-claim CDC control interface & send Samsung CDC-ACM 115200 8N1 + DTR/RTS
        if (protocol == DetectedProtocol.ODIN && ctrlIface != null) {
            if (conn.claimInterface(ctrlIface, true)) {
                val lineCoding = ByteBuffer.allocate(7).order(ByteOrder.LITTLE_ENDIAN).apply {
                    putInt(115200)
                    put(0x00) // 1 stop bit
                    put(0x00) // no parity
                    put(0x08) // 8 data bits
                }.array()

                conn.controlTransfer(0x21, 0x20, 0, ctrlIface.id, lineCoding, lineCoding.size, 1500)
                conn.controlTransfer(0x21, 0x22, 0x0003, ctrlIface.id, null, 0, 1500)
                onLog("درایور نیتیو Samsung CDC-ACM مقداردهی شد (115200 8N1 · DTR+RTS).")
            } else {
                ctrlIface = null
            }
        }

        if (!conn.claimInterface(dataIface, true)) {
            ctrlIface?.let { conn.releaseInterface(it) }
            conn.close()
            throw IllegalStateException("تصاحب اینترفیس داده #${dataIface.id} ناموفق بود.")
        }

        onLog(
            "اتصال سخت‌افزاری برقرار شد: Interface #${dataIface.id} · OUT=0x%02X · IN=0x%02X (%dB)"
                .format(epOut.address, epIn.address, epIn.maxPacketSize)
        )

        return UsbBinding(
            device = device,
            connection = conn,
            protocol = protocol,
            dataInterface = dataIface,
            controlInterface = ctrlIface,
            epIn = epIn,
            epOut = epOut
        )
    }

    private fun findBulkEndpoints(iface: UsbInterface): Pair<UsbEndpoint?, UsbEndpoint?> {
        var inEp: UsbEndpoint? = null
        var outEp: UsbEndpoint? = null
        for (j in 0 until iface.endpointCount) {
            val ep = iface.getEndpoint(j)
            if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep
                if (ep.direction == UsbConstants.USB_DIR_OUT) outEp = ep
            }
        }
        return inEp to outEp
    }
}
