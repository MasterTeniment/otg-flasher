package com.flashodin.app

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.UsbOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.flashodin.app.protocol.AdbProtocol
import com.flashodin.app.protocol.FastbootProtocol
import com.flashodin.app.protocol.OdinProtocol
import com.flashodin.app.protocol.OdinSlotInput
import com.flashodin.app.protocol.PitEntry
import com.flashodin.app.usb.DetectedProtocol
import com.flashodin.app.usb.NativeUsbCore
import com.flashodin.app.usb.UsbBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val ACTION_USB_PERMISSION = "com.flashodin.app.USB_PERMISSION"

data class PickedFile(
    val uri: Uri,
    val name: String,
    val size: Long,
    val enabled: Boolean = true
)

private data class OdinSlotMeta(
    val key: String,
    val titleFa: String,
    val hintFa: String,
    val accent: Color
)

private val ODIN_SLOTS = listOf(
    OdinSlotMeta("BL", "بوت‌لودر", "فایل BL_...tar.md5", Color(0xFF60A5FA)),
    OdinSlotMeta("AP", "سیستم و کرنل", "فایل AP_...tar.md5", Color(0xFF34D399)),
    OdinSlotMeta("CP", "مودم و آنتن", "فایل CP_...tar.md5", Color(0xFFFBBF24)),
    OdinSlotMeta("CSC", "منطقه و تنظیمات", "فایل CSC / HOME_CSC", Color(0xFFC084FC))
)

class MainActivity : ComponentActivity() {
    private lateinit var usbManager: UsbManager
    private val logs = mutableStateListOf<String>()
    private val attachedDevices = mutableStateListOf<UsbDevice>()
    private var activeBinding by mutableStateOf<UsbBinding?>(null)
    private var activeAdb by mutableStateOf<AdbProtocol?>(null)
    private var activeOdin by mutableStateOf<OdinProtocol?>(null)
    private var activeFastboot by mutableStateOf<FastbootProtocol?>(null)
    private var pitEntries by mutableStateOf<List<PitEntry>>(emptyList())
    private var statusMessage by mutableStateOf("آماده اتصال — گوشی مقصد را با کابل OTG وصل کنید")
    private var isBusy by mutableStateOf(false)
    private var progressFraction by mutableFloatStateOf(0f)
    private var progressLabel by mutableStateOf("")

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                ACTION_USB_PERMISSION -> {
                    val device = extractUsbDevice(intent)
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    if (granted && device != null) {
                        addLog("مجوز سخت‌افزاری USB برای ${NativeUsbCore.describeDevice(device)} تایید شد.")
                        connectToDevice(device)
                    } else {
                        addLog("مجوز USB توسط کاربر رد شد.")
                        statusMessage = "مجوز دسترسی به پورت USB رد شد"
                    }
                }

                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    val device = extractUsbDevice(intent)
                    refreshUsbDevices()
                    if (device != null) {
                        addLog("دستگاه USB متصل شد: ${NativeUsbCore.describeDevice(device)}")
                        requestPermissionAndConnect(device)
                    }
                }

                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    val device = extractUsbDevice(intent)
                    if (device != null && activeBinding?.device?.deviceId == device.deviceId) {
                        disconnectActive()
                        addLog("اتصال کابل USB قطع شد.")
                    }
                    refreshUsbDevices()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager

        val filter = IntentFilter().apply {
            addAction(ACTION_USB_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(this, usbReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)

        addLog("فلش‌ادین نیتیو v1.1 آماده شد (Odin 4-File BL/AP/CP/CSC + Heimdall Padding + LZ4 + ADB/Fastboot).")
        refreshUsbDevices()

        extractUsbDevice(intent)?.let { attached ->
            requestPermissionAndConnect(attached)
        }

        val scheme = darkColorScheme(
            primary = Color(0xFF3B82F6),
            onPrimary = Color.White,
            secondary = Color(0xFF10B981),
            background = Color(0xFF090D16),
            surface = Color(0xFF111827),
            surfaceVariant = Color(0xFF1E293B),
            onBackground = Color(0xFFF1F5F9),
            onSurface = Color(0xFFF1F5F9),
            error = Color(0xFFEF4444)
        )

        setContent {
            MaterialTheme(colorScheme = scheme) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    FlashOdinNativeScreen()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(usbReceiver)
        } catch (_: Exception) {
        }
        disconnectActive()
    }

    private fun extractUsbDevice(intent: Intent?): UsbDevice? {
        if (intent == null) return null
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
        }
    }

    private fun addLog(message: String) {
        val ts = timeFormat.format(Date())
        runOnUiThread {
            logs.add(0, "[$ts] $message")
            if (logs.size > 300) {
                logs.removeAt(logs.lastIndex)
            }
        }
    }

    private fun refreshUsbDevices() {
        val list = NativeUsbCore.listAttachedDevices(usbManager)
        runOnUiThread {
            attachedDevices.clear()
            attachedDevices.addAll(list)
            if (list.isEmpty() && activeBinding == null) {
                statusMessage = "هیچ دستگاهی روی پورت OTG یافت نشد"
            } else if (activeBinding == null) {
                statusMessage = "${list.size} دستگاه USB شناسایی شد — برای اتصال لمس کنید"
            }
        }
    }

    private fun requestPermissionAndConnect(device: UsbDevice) {
        if (usbManager.hasPermission(device)) {
            connectToDevice(device)
        } else {
            addLog("درخواست مجوز اندروید برای ${NativeUsbCore.describeDevice(device)}...")
            val explicitIntent = Intent(ACTION_USB_PERMISSION).setPackage(packageName)
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            val pendingIntent = PendingIntent.getBroadcast(this, 0, explicitIntent, flags)
            usbManager.requestPermission(device, pendingIntent)
        }
    }

    private fun disconnectActive() {
        activeBinding?.close()
        activeBinding = null
        activeOdin = null
        activeFastboot = null
        activeAdb = null
        pitEntries = emptyList()
        progressFraction = 0f
        progressLabel = ""
        statusMessage = "اتصال قطع شد"
    }

    private fun connectToDevice(device: UsbDevice) {
        Thread {
            try {
                runOnUiThread {
                    isBusy = true
                    statusMessage = "در حال اتصال و تشخیص خودکار پروتکل..."
                }
                disconnectActive()
                val binding = NativeUsbCore.bindDevice(usbManager, device) { addLog(it) }

                when (binding.protocol) {
                    DetectedProtocol.ODIN -> {
                        val odin = OdinProtocol(binding)
                        val hs = odin.handshake { addLog(it) }
                        // Auto-read PIT right after handshake so partition table is ready immediately
                        val pit = runCatching { odin.dumpPit { addLog(it) } }.getOrElse { err ->
                            addLog("هشدار خواندن خودکار PIT: ${err.message}")
                            emptyList()
                        }
                        runOnUiThread {
                            activeBinding = binding
                            activeOdin = odin
                            pitEntries = pit
                            statusMessage = "متصل به Odin v${hs.protocolVersion}.0 (${pit.size} پارتیشن PIT) — ${NativeUsbCore.describeDevice(device)}"
                        }
                    }

                    DetectedProtocol.ADB -> {
                        val adb = AdbProtocol(binding)
                        val banner = adb.connectAndAuth { addLog(it) }
                        runOnUiThread {
                            activeBinding = binding
                            activeAdb = adb
                            statusMessage = "متصل به ADB — ${banner.ifBlank { NativeUsbCore.describeDevice(device) }}"
                        }
                    }

                    DetectedProtocol.FASTBOOT -> {
                        val fb = FastbootProtocol(binding)
                        val prod = runCatching { fb.sendCommand("getvar:product").message }.getOrDefault("")
                        addLog("حالت Fastboot آماده است (product=${prod.ifBlank { "unknown" }}).")
                        runOnUiThread {
                            activeBinding = binding
                            activeFastboot = fb
                            statusMessage = "متصل به Fastboot — ${prod.ifBlank { NativeUsbCore.describeDevice(device) }}"
                        }
                    }

                    else -> {
                        binding.close()
                        throw IllegalStateException("پروتکل قابل فلش (Odin/ADB/Fastboot) روی این دستگاه فعال نیست.")
                    }
                }
            } catch (e: Exception) {
                addLog("خطای اتصال: ${e.message ?: "نامشخص"}")
                runOnUiThread {
                    statusMessage = e.message ?: "خطا در برقراری اتصال USB"
                }
            } finally {
                runOnUiThread { isBusy = false }
            }
        }.start()
    }

    private fun resolvePickedFile(uri: Uri): PickedFile {
        var name = "firmware.bin"
        var size = -1L
        contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIdx >= 0) name = cursor.getString(nameIdx) ?: name
                if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) size = cursor.getLong(sizeIdx)
            }
        }
        if (size <= 0L) {
            size = runCatching {
                contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: 0L
            }.getOrDefault(0L)
        }
        return PickedFile(uri = uri, name = name, size = maxOf(0L, size), enabled = true)
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun FlashOdinNativeScreen() {
        val scope = rememberCoroutineScope()
        var selectedTab by remember { mutableIntStateOf(0) }

        // 4 dedicated Odin firmware slots: BL, AP, CP, CSC
        val slotFiles = remember { mutableStateMapOf<String, PickedFile>() }
        var pickingSlotKey by remember { mutableStateOf("AP") }
        var autoReboot by remember { mutableStateOf(true) }

        var fastbootFile by remember { mutableStateOf<PickedFile?>(null) }
        var fastbootPartition by remember { mutableStateOf("boot") }
        var adbCommand by remember { mutableStateOf("getprop ro.product.model") }
        var adbOutput by remember { mutableStateOf("") }

        val odinSlotPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                val picked = resolvePickedFile(uri)
                slotFiles[pickingSlotKey] = picked
                addLog("اسلات $pickingSlotKey انتخاب شد: ${picked.name} (${formatBytes(picked.size)})")
            }
        }

        val fastbootPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                fastbootFile = resolvePickedFile(uri)
                addLog("ایمیج Fastboot انتخاب شد: ${fastbootFile?.name} (${formatBytes(fastbootFile?.size ?: 0L)})")
            }
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "فلش‌ادین نیتیو v1.1",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "Odin 4-File · UsbManager · ADB · Fastboot",
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF0F172A),
                        titleContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0F172A)) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Usb, contentDescription = null) },
                        label = { Text("ادین ۴فایله") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.Build, contentDescription = null) },
                        label = { Text("ADB / Fastboot") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.Terminal, contentDescription = null) },
                        label = { Text("گزارش (${logs.size})") }
                    )
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                UsbConnectionCard()

                if (progressFraction > 0f || isBusy) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = progressLabel.ifBlank { "در حال پردازش..." },
                                fontSize = 12.sp,
                                color = Color(0xFFCBD5E1),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "${(progressFraction * 100).toInt()}%",
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF60A5FA)
                            )
                        }
                        LinearProgressIndicator(
                            progress = { if (progressFraction > 0f) progressFraction else 0.12f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                        )
                    }
                }

                when (selectedTab) {
                    0 -> OdinFourFileTab(
                        slotFiles = slotFiles,
                        autoReboot = autoReboot,
                        onAutoRebootChange = { autoReboot = it },
                        onPickSlot = { key ->
                            pickingSlotKey = key
                            odinSlotPicker.launch(arrayOf("*/*"))
                        },
                        onToggleSlot = { key, enabled ->
                            slotFiles[key]?.let { slotFiles[key] = it.copy(enabled = enabled) }
                        },
                        onClearSlot = { key -> slotFiles.remove(key) },
                        onReadPit = {
                            val odin = activeOdin ?: return@OdinFourFileTab
                            scope.launch {
                                isBusy = true
                                progressLabel = "خواندن جدول PIT..."
                                try {
                                    val entries = withContext(Dispatchers.IO) {
                                        odin.dumpPit { addLog(it) }
                                    }
                                    pitEntries = entries
                                    statusMessage = "جدول PIT خوانده شد (${entries.size} پارتیشن)"
                                } catch (e: Exception) {
                                    addLog("خطای خواندن PIT: ${e.message}")
                                    statusMessage = e.message ?: "خطای PIT"
                                } finally {
                                    isBusy = false
                                    progressLabel = ""
                                }
                            }
                        },
                        onStartFlash = {
                            val odin = activeOdin ?: return@OdinFourFileTab
                            val selectedInputs = ODIN_SLOTS.mapNotNull { meta ->
                                val f = slotFiles[meta.key]
                                if (f != null && f.enabled) {
                                    OdinSlotInput(meta.key, f.uri, f.name, f.size)
                                } else {
                                    null
                                }
                            }
                            if (selectedInputs.isEmpty()) return@OdinFourFileTab

                            scope.launch {
                                isBusy = true
                                progressFraction = 0.01f
                                progressLabel = "آماده‌سازی ${selectedInputs.size} فایل برای فلش..."
                                try {
                                    withContext(Dispatchers.IO) {
                                        val pit = pitEntries.ifEmpty {
                                            odin.dumpPit { addLog(it) }.also { loaded ->
                                                runOnUiThread { pitEntries = loaded }
                                            }
                                        }
                                        odin.flashSlots(
                                            resolver = contentResolver,
                                            slots = selectedInputs,
                                            pit = pit,
                                            autoReboot = autoReboot,
                                            onLog = { addLog(it) },
                                            onProgress = { sent, total, label ->
                                                val frac = if (total > 0L) sent.toFloat() / total.toFloat() else 0f
                                                runOnUiThread {
                                                    progressFraction = frac.coerceIn(0f, 1f)
                                                    progressLabel = "$label (${formatBytes(sent)} / ${formatBytes(total)})"
                                                }
                                            }
                                        )
                                    }
                                    progressFraction = 1f
                                    statusMessage = "PASS! همه اسلات‌ها با موفقیت فلش شدند"
                                } catch (e: Exception) {
                                    addLog("خطای فلش Odin: ${e.message}")
                                    statusMessage = e.message ?: "خطا حین فلش"
                                } finally {
                                    isBusy = false
                                }
                            }
                        }
                    )

                    1 -> AdbFastbootTab(
                        adbCommand = adbCommand,
                        onAdbCommandChange = { adbCommand = it },
                        adbOutput = adbOutput,
                        onRunAdbShell = {
                            val adb = activeAdb ?: return@AdbFastbootTab
                            scope.launch {
                                isBusy = true
                                try {
                                    addLog("adb shell > $adbCommand")
                                    val res = withContext(Dispatchers.IO) { adb.shell(adbCommand) }
                                    adbOutput = res.ifBlank { "(خروجی خالی)" }
                                    addLog(adbOutput.take(240))
                                } catch (e: Exception) {
                                    addLog("خطای ADB Shell: ${e.message}")
                                } finally {
                                    isBusy = false
                                }
                            }
                        },
                        onAdbReboot = { target ->
                            val adb = activeAdb ?: return@AdbFastbootTab
                            scope.launch {
                                isBusy = true
                                try {
                                    addLog("ارسال دستور ریبوت ADB به حالت: $target")
                                    withContext(Dispatchers.IO) { adb.reboot(target) }
                                    statusMessage = "دستور انتقال به $target ارسال شد"
                                } catch (e: Exception) {
                                    addLog("خطای ریبوت ADB: ${e.message}")
                                } finally {
                                    isBusy = false
                                }
                            }
                        },
                        fastbootFile = fastbootFile,
                        fastbootPartition = fastbootPartition,
                        onFastbootPartitionChange = { fastbootPartition = it },
                        onPickFastbootFile = { fastbootPicker.launch(arrayOf("*/*")) },
                        onFastbootFlash = {
                            val fb = activeFastboot ?: return@AdbFastbootTab
                            val file = fastbootFile ?: return@AdbFastbootTab
                            val part = fastbootPartition.trim().ifBlank { "boot" }
                            scope.launch {
                                isBusy = true
                                progressFraction = 0.01f
                                progressLabel = "فلش Fastboot ($part)..."
                                try {
                                    withContext(Dispatchers.IO) {
                                        fb.flashUri(
                                            resolver = contentResolver,
                                            partition = part,
                                            uri = file.uri,
                                            fileSize = file.size,
                                            onLog = { addLog(it) },
                                            onProgress = { sent, total ->
                                                val frac = if (total > 0L) sent.toFloat() / total.toFloat() else 0f
                                                runOnUiThread {
                                                    progressFraction = frac.coerceIn(0f, 1f)
                                                    progressLabel = "ارسال $part (${formatBytes(sent)} / ${formatBytes(total)})"
                                                }
                                            }
                                        )
                                    }
                                    progressFraction = 1f
                                    statusMessage = "پارتیشن $part با موفقیت فلش شد"
                                } catch (e: Exception) {
                                    addLog("خطای Fastboot: ${e.message}")
                                    statusMessage = e.message ?: "خطای Fastboot"
                                } finally {
                                    isBusy = false
                                }
                            }
                        },
                        onFastbootCommand = { cmd ->
                            val fb = activeFastboot ?: return@AdbFastbootTab
                            scope.launch {
                                isBusy = true
                                try {
                                    addLog("fastboot > $cmd")
                                    val r = withContext(Dispatchers.IO) { fb.sendCommand(cmd) }
                                    r.infoLines.forEach { addLog("INFO: $it") }
                                    addLog("${r.status}: ${r.message}")
                                } catch (e: Exception) {
                                    addLog("خطای دستور Fastboot: ${e.message}")
                                } finally {
                                    isBusy = false
                                }
                            }
                        }
                    )

                    else -> LogsTab()
                }
            }
        }
    }

    @Composable
    private fun UsbConnectionCard() {
        val connected = activeBinding != null
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (connected) "اتصال سخت‌افزاری برقرار است" else "وضعیت پورت USB OTG",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (connected) Color(0xFF34D399) else Color.White
                        )
                        Text(
                            text = statusMessage,
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    if (connected) {
                        OutlinedButton(onClick = { disconnectActive() }, enabled = !isBusy) {
                            Icon(Icons.Default.UsbOff, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("قطع", fontSize = 12.sp)
                        }
                    } else {
                        Button(
                            onClick = {
                                refreshUsbDevices()
                                val first = attachedDevices.firstOrNull()
                                if (first != null) {
                                    requestPermissionAndConnect(first)
                                } else {
                                    addLog("اسکن پورت OTG: دستگاهی متصل نیست.")
                                }
                            },
                            enabled = !isBusy
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("اسکن و اتصال", fontSize = 12.sp)
                        }
                    }
                }

                if (!connected && attachedDevices.isNotEmpty()) {
                    HorizontalDivider(color = Color(0xFF1E293B))
                    attachedDevices.forEach { dev ->
                        val proto = NativeUsbCore.detectProtocol(dev)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = NativeUsbCore.describeDevice(dev),
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFFE2E8F0)
                                )
                                Text(
                                    text = "پروتکل تشخیص‌داده‌شده: $proto",
                                    fontSize = 11.sp,
                                    color = Color(0xFF60A5FA)
                                )
                            }
                            OutlinedButton(
                                onClick = { requestPermissionAndConnect(dev) },
                                enabled = !isBusy
                            ) {
                                Text("اتصال", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun OdinFourFileTab(
        slotFiles: Map<String, PickedFile>,
        autoReboot: Boolean,
        onAutoRebootChange: (Boolean) -> Unit,
        onPickSlot: (String) -> Unit,
        onToggleSlot: (String, Boolean) -> Unit,
        onClearSlot: (String) -> Unit,
        onReadPit: () -> Unit,
        onStartFlash: () -> Unit
    ) {
        val activeSlotCount = ODIN_SLOTS.count { slotFiles[it.key]?.enabled == true }
        val odinReady = activeOdin != null && !isBusy

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "اسلات‌های رام ۴ فایله سامسونگ",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "یک یا هر چهار فایل BL / AP / CP / CSC را انتخاب کنید (پشتیبانی کامل از .tar، .tar.md5 و .lz4).",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )

                    ODIN_SLOTS.forEach { slotMeta ->
                        val picked = slotFiles[slotMeta.key]
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF0B1220), RoundedCornerShape(12.dp))
                                .border(
                                    width = 1.dp,
                                    color = if (picked != null && picked.enabled) slotMeta.accent.copy(alpha = 0.6f) else Color(0xFF1E293B),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = picked?.enabled == true,
                                enabled = picked != null && !isBusy,
                                onCheckedChange = { checked -> onToggleSlot(slotMeta.key, checked) }
                            )

                            OutlinedButton(
                                onClick = { onPickSlot(slotMeta.key) },
                                enabled = !isBusy,
                                modifier = Modifier.width(70.dp)
                            ) {
                                Text(
                                    text = slotMeta.key,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = slotMeta.accent,
                                    fontSize = 13.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                if (picked != null) {
                                    Text(
                                        text = picked.name,
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = Color(0xFFF1F5F9),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${slotMeta.titleFa} · ${formatBytes(picked.size)}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                } else {
                                    Text(
                                        text = slotMeta.titleFa,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFFCBD5E1)
                                    )
                                    Text(
                                        text = slotMeta.hintFa,
                                        fontSize = 11.sp,
                                        color = Color(0xFF64748B)
                                    )
                                }
                            }

                            if (picked != null && !isBusy) {
                                IconButton(onClick = { onClearSlot(slotMeta.key) }) {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "حذف",
                                        tint = Color(0xFF94A3B8),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "ریبوت خودکار پس از پایان فلش",
                            fontSize = 13.sp,
                            color = Color(0xFFE2E8F0),
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Switch(checked = autoReboot, onCheckedChange = onAutoRebootChange)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onReadPit,
                            enabled = odinReady,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("خواندن PIT", maxLines = 1)
                        }
                        Button(
                            onClick = onStartFlash,
                            enabled = odinReady && activeSlotCount > 0,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                            modifier = Modifier.weight(1.5f)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (activeSlotCount > 1) "شروع فلش ($activeSlotCount فایل)" else "شروع فلش",
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            if (pitEntries.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "جدول پارتیشن PIT گوشی (${pitEntries.size} پارتیشن)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        pitEntries.take(25).forEach { entry ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "#${entry.partitionId} ${entry.partitionName}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = Color(0xFFE2E8F0)
                                )
                                Text(
                                    text = entry.flashFilename.ifBlank { "-" },
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = Color(0xFF60A5FA)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun AdbFastbootTab(
        adbCommand: String,
        onAdbCommandChange: (String) -> Unit,
        adbOutput: String,
        onRunAdbShell: () -> Unit,
        onAdbReboot: (String) -> Unit,
        fastbootFile: PickedFile?,
        fastbootPartition: String,
        onFastbootPartitionChange: (String) -> Unit,
        onPickFastbootFile: () -> Unit,
        onFastbootFlash: () -> Unit,
        onFastbootCommand: (String) -> Unit
    ) {
        val adbReady = activeAdb != null && !isBusy
        val fbReady = activeFastboot != null && !isBusy

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "کنترل ADB (انتقال به دانلود مود و Shell)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = { onAdbReboot("download") },
                            enabled = adbReady,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Download", fontSize = 11.sp, maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = { onAdbReboot("bootloader") },
                            enabled = adbReady,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Fastboot", fontSize = 11.sp, maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = { onAdbReboot("recovery") },
                            enabled = adbReady,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Recovery", fontSize = 11.sp, maxLines = 1)
                        }
                    }

                    OutlinedTextField(
                        value = adbCommand,
                        onValueChange = onAdbCommandChange,
                        label = { Text("دستور ADB Shell") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = onRunAdbShell,
                        enabled = adbReady && adbCommand.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("اجرای دستور Shell")
                    }

                    if (adbOutput.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF020617), RoundedCornerShape(10.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = adbOutput,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = Color(0xFF34D399)
                            )
                        }
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "فلشر Fastboot (شیائومی، پیکسل، وان‌پلاس)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    OutlinedTextField(
                        value = fastbootPartition,
                        onValueChange = onFastbootPartitionChange,
                        label = { Text("نام پارتیشن (مثلاً boot, recovery, vbmeta)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedButton(
                        onClick = onPickFastbootFile,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = fastbootFile?.let { "${it.name} (${formatBytes(it.size)})" }
                                ?: "انتخاب فایل ایمیج (.img)",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onFastbootFlash,
                            enabled = fbReady && fastbootFile != null,
                            modifier = Modifier.weight(1.4f)
                        ) {
                            Text("فلش پارتیشن")
                        }
                        OutlinedButton(
                            onClick = { onFastbootCommand("reboot") },
                            enabled = fbReady,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("ریبوت")
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun LogsTab() {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("گزارش زنده سخت‌افزار USB", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                OutlinedButton(onClick = { logs.clear() }) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("پاک کردن", fontSize = 12.sp)
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF020617), RoundedCornerShape(14.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(logs) { line ->
                    Text(
                        text = line,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = Color(0xFFCBD5E1),
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return "%.1f KB".format(Locale.US, kb)
        val mb = kb / 1024.0
        if (mb < 1024.0) return "%.1f MB".format(Locale.US, mb)
        return "%.2f GB".format(Locale.US, mb / 1024.0)
    }
}
