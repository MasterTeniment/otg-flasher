package com.flashodin.app.protocol

import android.content.ContentResolver
import android.net.Uri
import com.flashodin.app.usb.UsbBinding
import java.io.BufferedInputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.min

data class PitEntry(
    val binaryType: Int,
    val deviceType: Int,
    val partitionId: Int,
    val blockCount: Int,
    val partitionName: String,
    val flashFilename: String
)

data class OdinHandshakeInfo(
    val protocolVersion: Int,
    val maxPacketSize: Int,
    val supportsCustomPartSize: Boolean
)

data class OdinSlotInput(
    val slotKey: String, // BL, AP, CP, CSC
    val uri: Uri,
    val fileName: String,
    val fileSize: Long
)

private data class PlannedMember(
    val slot: OdinSlotInput,
    val memberName: String,
    val tarDataSize: Long,
    val uncompressedSize: Long,
    val isLz4: Boolean,
    val pitEntry: PitEntry
)

/**
 * Pure-Kotlin streaming LZ4 Frame decoder (magic 0x184D2204) for modern Samsung .img.lz4 / .bin.lz4 firmware.
 */
private class Lz4FrameInputStream(private val source: InputStream) : InputStream() {
    private var contentChecksumFlag = false
    private var blockChecksumFlag = false
    private var eof = false
    private var outBuf = ByteArray(0)
    private var outPos = 0
    private var outLen = 0
    private val history = ByteArray(65536)
    private var historyPos = 0
    private var historySize = 0
    var declaredContentSize: Long? = null
        private set

    init {
        parseHeader()
    }

    private fun readByteStrict(): Int {
        val b = source.read()
        if (b < 0) throw IllegalStateException("پایان غیرمنتظره استریم LZ4")
        return b
    }

    private fun readFullyStrict(dst: ByteArray, len: Int) {
        var off = 0
        while (off < len) {
            val r = source.read(dst, off, len - off)
            if (r < 0) throw IllegalStateException("پایان غیرمنتظره داده در فایل LZ4")
            off += r
        }
    }

    private fun readUInt32LE(): Int {
        val b0 = readByteStrict()
        val b1 = readByteStrict()
        val b2 = readByteStrict()
        val b3 = readByteStrict()
        return b0 or (b1 shl 8) or (b2 shl 16) or (b3 shl 24)
    }

    private fun readUInt64LE(): Long {
        val lo = readUInt32LE().toLong() and 0xFFFFFFFFL
        val hi = readUInt32LE().toLong() and 0xFFFFFFFFL
        return lo or (hi shl 32)
    }

    private fun parseHeader() {
        val magic = readUInt32LE()
        if (magic != 0x184D2204) {
            throw IllegalStateException("فرمت فایل LZ4 معتبر نیست (Magic: 0x%08X)".format(magic))
        }
        val flg = readByteStrict()
        val bd = readByteStrict()
        val blockMaxCode = (bd ushr 4) and 0x07
        val maxBlockSize = when (blockMaxCode) {
            4 -> 64 * 1024
            5 -> 256 * 1024
            6 -> 1024 * 1024
            7 -> 4 * 1024 * 1024
            else -> 4 * 1024 * 1024
        }
        outBuf = ByteArray(maxBlockSize)
        blockChecksumFlag = (flg and 0x10) != 0
        contentChecksumFlag = (flg and 0x04) != 0
        val hasContentSize = (flg and 0x08) != 0
        val hasDictId = (flg and 0x01) != 0
        if (hasContentSize) {
            declaredContentSize = readUInt64LE()
        }
        if (hasDictId) {
            readUInt32LE()
        }
        readByteStrict() // Header checksum
    }

    private fun pushHistory(byteVal: Byte) {
        history[historyPos] = byteVal
        historyPos = (historyPos + 1) and 0xFFFF
        if (historySize < 65536) historySize++
    }

    private fun fillNextBlock(): Boolean {
        if (eof) return false
        val blockSizeWord = readUInt32LE()
        if (blockSizeWord == 0) {
            if (contentChecksumFlag) {
                readUInt32LE()
            }
            eof = true
            return false
        }
        val isUncompressed = (blockSizeWord and Int.MIN_VALUE) != 0
        val compSize = blockSizeWord and 0x7FFFFFFF
        val compBuf = ByteArray(compSize)
        readFullyStrict(compBuf, compSize)
        if (blockChecksumFlag) {
            readUInt32LE()
        }

        outPos = 0
        if (isUncompressed) {
            if (compSize > outBuf.size) outBuf = ByteArray(compSize)
            System.arraycopy(compBuf, 0, outBuf, 0, compSize)
            outLen = compSize
            for (i in 0 until compSize) pushHistory(outBuf[i])
            return true
        }

        var ip = 0
        var op = 0
        while (ip < compSize) {
            val token = compBuf[ip++].toInt() and 0xFF
            var litLen = token ushr 4
            if (litLen == 15) {
                var s: Int
                do {
                    s = compBuf[ip++].toInt() and 0xFF
                    litLen += s
                } while (s == 255)
            }
            if (op + litLen > outBuf.size) {
                outBuf = outBuf.copyOf(maxOf(outBuf.size * 2, op + litLen + 65536))
            }
            System.arraycopy(compBuf, ip, outBuf, op, litLen)
            for (i in 0 until litLen) pushHistory(outBuf[op + i])
            ip += litLen
            op += litLen
            if (ip >= compSize) break

            val offset = (compBuf[ip].toInt() and 0xFF) or ((compBuf[ip + 1].toInt() and 0xFF) shl 8)
            ip += 2
            var matchLen = (token and 0x0F) + 4
            if ((token and 0x0F) == 15) {
                var s: Int
                do {
                    s = compBuf[ip++].toInt() and 0xFF
                    matchLen += s
                } while (s == 255)
            }
            if (op + matchLen > outBuf.size) {
                outBuf = outBuf.copyOf(maxOf(outBuf.size * 2, op + matchLen + 65536))
            }
            for (i in 0 until matchLen) {
                val srcIdx = (historyPos - offset) and 0xFFFF
                val b = history[srcIdx]
                outBuf[op++] = b
                pushHistory(b)
            }
        }
        outLen = op
        return true
    }

    override fun read(): Int {
        val one = ByteArray(1)
        val r = read(one, 0, 1)
        return if (r <= 0) -1 else (one[0].toInt() and 0xFF)
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (len == 0) return 0
        if (outPos >= outLen) {
            if (!fillNextBlock()) return -1
        }
        val avail = outLen - outPos
        val take = min(avail, len)
        System.arraycopy(outBuf, outPos, b, off, take)
        outPos += take
        return take
    }
}

private class BoundedInputStream(
    private val delegate: InputStream,
    private var remaining: Long
) : InputStream() {
    override fun read(): Int {
        if (remaining <= 0L) return -1
        val b = delegate.read()
        if (b >= 0) remaining--
        return b
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (remaining <= 0L) return -1
        val toRead = min(len.toLong(), remaining).toInt()
        val r = delegate.read(b, off, toRead)
        if (r > 0) remaining -= r
        return r
    }

    fun drainRemaining() {
        val skipBuf = ByteArray(16384)
        while (remaining > 0L) {
            val s = delegate.skip(remaining)
            if (s > 0L) {
                remaining -= s
            } else {
                val r = delegate.read(skipBuf, 0, min(skipBuf.size.toLong(), remaining).toInt())
                if (r < 0) break
                remaining -= r
            }
        }
    }
}

class OdinProtocol(private val binding: UsbBinding) {
    companion object {
        private const val PACKET_SIZE = 1024
        private const val CMD_SESSION = 0x64
        private const val CMD_PIT = 0x65
        private const val CMD_FLASH = 0x66
        private const val CMD_END = 0x67

        private const val SESSION_BEGIN = 0x00
        private const val SESSION_TOTAL_BYTES = 0x02
        private const val SESSION_FILE_PART_SIZE = 0x05

        private const val PIT_DUMP_REQ = 0x01
        private const val PIT_DUMP_PART = 0x02
        private const val PIT_DUMP_END = 0x03

        private const val FLASH_START = 0x00
        private const val FLASH_SEQ_START = 0x02
        private const val FLASH_SEQ_END = 0x03

        private const val END_SESSION = 0x00
        private const val END_REBOOT = 0x01

        private const val PIT_MAGIC = 0x12349876
        private const val TAR_BLOCK = 512

        // Safe OTG packet size (128 KiB, exact multiple of 512B USB Bulk maxPacketSize)
        private const val OTG_FILE_PART_SIZE = 131072
        private const val SEQUENCE_MAX_PARTS = 240 // 240 * 128 KiB = 30 MiB per Odin sequence
    }

    private var supportsCustomPartSize = false

    private fun buildCmd(cmd: Int, sub: Int, a1: Int = 0, a2: Int = 0, a3: Int = 0): ByteArray {
        val buf = ByteBuffer.allocate(PACKET_SIZE).order(ByteOrder.LITTLE_ENDIAN)
        buf.putInt(cmd)
        buf.putInt(sub)
        buf.putInt(a1)
        buf.putInt(a2)
        buf.putInt(a3)
        return buf.array()
    }

    private fun writeAll(data: ByteArray, length: Int = data.size, timeoutMs: Int = 30000) {
        var sent = 0
        while (sent < length) {
            val written = binding.connection.bulkTransfer(binding.epOut, data, sent, length - sent, timeoutMs)
            if (written <= 0) {
                throw IllegalStateException("خطا در ارسال داده Bulk OUT (کد: $written)")
            }
            sent += written
        }
    }

    private fun readReply(minLen: Int = 8, timeoutMs: Int = 15000): ByteArray {
        val unit = maxOf(64, binding.epIn.maxPacketSize)
        val reqLen = ceil(maxOf(minLen, unit).toDouble() / unit).toInt() * unit
        val buf = ByteArray(reqLen)
        val read = binding.connection.bulkTransfer(binding.epIn, buf, buf.size, timeoutMs)
        if (read <= 0) {
            throw IllegalStateException("پاسخی از گوشی در Download Mode دریافت نشد (Timeout/کد: $read)")
        }
        return buf.copyOf(read)
    }

    fun handshake(onLog: (String) -> Unit): OdinHandshakeInfo {
        val odinBytes = "ODIN".toByteArray(Charsets.US_ASCII)
        var ok = false
        var lastReply = ""

        for (attempt in 1..3) {
            onLog("ارسال بسته ODIN (تلاش $attempt از ۳)...")
            try {
                writeAll(odinBytes, timeoutMs = 4000)
                val rep = readReply(4, timeoutMs = 4000)
                lastReply = String(rep, Charsets.US_ASCII).trim('\u0000', ' ', '\r', '\n')
                if (lastReply.startsWith("LOKE")) {
                    ok = true
                    break
                }
            } catch (e: Exception) {
                if (attempt == 3) throw e
                Thread.sleep(300)
            }
        }

        if (!ok) {
            throw IllegalStateException("پاسخ LOKE دریافت نشد (پاسخ: \"$lastReply\")")
        }
        onLog("پاسخ LOKE دریافت شد! شروع نشست Odin...")

        // Heimdall BeginSessionPacket (0x64, 0x00, 0x00000000)
        writeAll(buildCmd(CMD_SESSION, SESSION_BEGIN, 0))
        val sessionRep = readReply(8, timeoutMs = 15000)
        val view = ByteBuffer.wrap(sessionRep).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = view.getInt(0)
        val defaultPacketSize = view.getInt(4)
        if (cmd != CMD_SESSION) {
            throw IllegalStateException("خطا در شروع نشست Odin (0x%X)".format(cmd))
        }

        supportsCustomPartSize = defaultPacketSize != 0
        val protoVer = if (supportsCustomPartSize) 3 else 2
        onLog(
            "نشست Odin v$protoVer.0 فعال شد (پشتیبانی تنظیم بسته: ${if (supportsCustomPartSize) "بله" else "ثابت 128KB"})."
        )
        return OdinHandshakeInfo(protoVer, OTG_FILE_PART_SIZE, supportsCustomPartSize)
    }

    fun dumpPit(onLog: (String) -> Unit): List<PitEntry> {
        onLog("درخواست خواندن جدول پارتیشن (PIT)...")
        writeAll(buildCmd(CMD_PIT, PIT_DUMP_REQ))
        val sizeRep = ByteBuffer.wrap(readReply(8)).order(ByteOrder.LITTLE_ENDIAN)
        val pitSize = sizeRep.getInt(4)
        if (pitSize <= 28 || pitSize > 1024 * 1024) {
            throw IllegalStateException("اندازه PIT نامعتبر است: $pitSize")
        }

        val pitBytes = ByteArray(pitSize)
        val partSize = 500
        val totalParts = ceil(pitSize.toDouble() / partSize).toInt()

        for (i in 0 until totalParts) {
            writeAll(buildCmd(CMD_PIT, PIT_DUMP_PART, i))
            val remain = pitSize - i * partSize
            val chunk = readReply(min(partSize, remain))
            val copyLen = min(chunk.size, remain)
            System.arraycopy(chunk, 0, pitBytes, i * partSize, copyLen)
        }

        writeAll(buildCmd(CMD_PIT, PIT_DUMP_END))
        readReply(8)

        val entries = parsePit(pitBytes)
        onLog("جدول PIT خوانده شد (${entries.size} پارتیشن).")
        return entries
    }

    private fun parsePit(bytes: ByteArray): List<PitEntry> {
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val magic = bb.getInt(0)
        if (magic != PIT_MAGIC) {
            throw IllegalStateException("امضای باینری PIT نامعتبر است.")
        }
        val count = bb.getInt(4)
        val list = mutableListOf<PitEntry>()
        for (i in 0 until count) {
            val base = 28 + i * 132
            if (base + 132 > bytes.size) break
            val binaryType = bb.getInt(base)
            val deviceType = bb.getInt(base + 4)
            val id = bb.getInt(base + 8)
            val blocks = bb.getInt(base + 24)
            val partName = readCString(bytes, base + 36, 32)
            val flashName = readCString(bytes, base + 68, 32)
            list.add(PitEntry(binaryType, deviceType, id, blocks, partName, flashName))
        }
        return list
    }

    private fun readCString(bytes: ByteArray, offset: Int, maxLen: Int): String {
        var end = offset
        val limit = min(offset + maxLen, bytes.size)
        while (end < limit && bytes[end].toInt() != 0) end++
        return String(bytes, offset, end - offset, Charsets.US_ASCII).trim()
    }

    private fun inspectLz4ContentSize(input: InputStream, compressedLen: Long): Long? {
        val header = ByteArray(15)
        val got = readFully(input, header, min(15L, compressedLen).toInt())
        if (got < 7) return null
        val bb = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        val magic = bb.getInt(0)
        if (magic != 0x184D2204) return null
        val flg = header[4].toInt() and 0xFF
        val hasContentSize = (flg and 0x08) != 0
        if (!hasContentSize || got < 15) return null
        return bb.getLong(6)
    }

    /**
     * Scans all selected slots (BL, AP, CP, CSC) to build an exact partition plan and total byte count.
     */
    private fun scanSlots(
        resolver: ContentResolver,
        slots: List<OdinSlotInput>,
        pit: List<PitEntry>,
        onLog: (String) -> Unit
    ): List<PlannedMember> {
        val planned = mutableListOf<PlannedMember>()
        for (slot in slots) {
            val lower = slot.fileName.lowercase()
            val isTar = lower.endsWith(".tar") || lower.endsWith(".tar.md5")

            resolver.openInputStream(slot.uri)?.use { rawIn ->
                val input = BufferedInputStream(rawIn, 256 * 1024)
                if (isTar) {
                    val header = ByteArray(TAR_BLOCK)
                    while (true) {
                        val read = readFully(input, header, TAR_BLOCK)
                        if (read < TAR_BLOCK || header.all { it.toInt() == 0 }) break
                        val memberName = readCString(header, 0, 100).removePrefix("./")
                        val sizeOct = readCString(header, 124, 12)
                        val memberSize = sizeOct.toLongOrNull(8) ?: 0L
                        val typeFlag = header[156].toInt() and 0xFF
                        if (memberName.isEmpty() || memberSize <= 0L) {
                            if (memberSize > 0L) {
                                skipExact(input, memberSize + tarPadding(memberSize))
                            }
                            if (memberName.isEmpty()) break else continue
                        }
                        if (typeFlag != 0 && typeFlag != '0'.code) {
                            skipExact(input, memberSize + tarPadding(memberSize))
                            continue
                        }

                        val pitMatch = matchPit(memberName, pit)
                        if (pitMatch == null) {
                            onLog("[${slot.slotKey}] رد کردن فایل غیرپارتیشنی: $memberName")
                            skipExact(input, memberSize + tarPadding(memberSize))
                            continue
                        }

                        val isLz4 = memberName.lowercase().endsWith(".lz4")
                        var uncompSize = memberSize
                        if (isLz4) {
                            val bounded = BoundedInputStream(input, memberSize)
                            val declared = inspectLz4ContentSize(bounded, memberSize)
                            if (declared != null && declared > 0L) {
                                uncompSize = declared
                                bounded.drainRemaining()
                            } else {
                                // Fallback: cannot know uncompressed size without full stream count; skip with warning
                                bounded.drainRemaining()
                                onLog("[${slot.slotKey}] هشدار: فایل $memberName بدون هدر Content-Size در LZ4 است و رد شد.")
                                val pad = tarPadding(memberSize)
                                if (pad > 0) skipExact(input, pad)
                                continue
                            }
                        } else {
                            skipExact(input, memberSize)
                        }

                        val pad = tarPadding(memberSize)
                        if (pad > 0) skipExact(input, pad)

                        planned.add(
                            PlannedMember(
                                slot = slot,
                                memberName = memberName,
                                tarDataSize = memberSize,
                                uncompressedSize = uncompSize,
                                isLz4 = isLz4,
                                pitEntry = pitMatch
                            )
                        )
                    }
                } else {
                    val pitMatch = matchPit(slot.fileName, pit)
                        ?: throw IllegalStateException("فایل ${slot.fileName} با هیچ پارتیشنی در جدول PIT گوشی مطابقت نداشت.")
                    val isLz4 = lower.endsWith(".lz4")
                    val uncompSize = if (isLz4) {
                        inspectLz4ContentSize(input, slot.fileSize)
                            ?: throw IllegalStateException("فایل LZ4 بدون هدر Content-Size پشتیبانی نمی‌شود.")
                    } else {
                        slot.fileSize
                    }
                    planned.add(
                        PlannedMember(
                            slot = slot,
                            memberName = slot.fileName,
                            tarDataSize = slot.fileSize,
                            uncompressedSize = uncompSize,
                            isLz4 = isLz4,
                            pitEntry = pitMatch
                        )
                    )
                }
            } ?: throw IllegalStateException("امکان خواندن فایل ${slot.fileName} وجود ندارد.")
        }
        return planned
    }

    /**
     * Flashes 1 to 4 Samsung Odin firmware slots (BL, AP, CP, CSC) sequentially in a single Odin session.
     * Follows the exact Heimdall/Loke wire protocol: padded file parts, padded sequence start,
     * proper EndPhone/EndModem fields with PIT deviceType, and 2-minute flash-commit timeout.
     */
    fun flashSlots(
        resolver: ContentResolver,
        slots: List<OdinSlotInput>,
        pit: List<PitEntry>,
        autoReboot: Boolean,
        onLog: (String) -> Unit,
        onProgress: (sent: Long, total: Long, label: String) -> Unit
    ) {
        if (slots.isEmpty()) {
            throw IllegalStateException("هیچ فایلی در اسلات‌های BL / AP / CP / CSC انتخاب نشده است.")
        }
        if (pit.isEmpty()) {
            throw IllegalStateException("جدول PIT گوشی خوانده نشده است. ابتدا PIT را بخوانید یا دوباره متصل شوید.")
        }

        onLog("بررسی و تطبیق پارتیشن‌های ${slots.size} اسلات با جدول PIT گوشی...")
        val plan = scanSlots(resolver, slots, pit, onLog)
        if (plan.isEmpty()) {
            throw IllegalStateException("هیچ پارتیشن منطبقی با PIT گوشی در فایل‌های انتخاب‌شده پیدا نشد.")
        }

        val totalUncompressedBytes = plan.sumOf { it.uncompressedSize }
        onLog("تایید شد: ${plan.size} پارتیشن آماده فلش (حجم کل: ${"%.2f".format(Locale.US, totalUncompressedBytes / (1024.0 * 1024.0))} MB).")

        // 1. Send File Part Size (0x64, 0x05) ONLY if device supports custom part size
        if (supportsCustomPartSize) {
            writeAll(buildCmd(CMD_SESSION, SESSION_FILE_PART_SIZE, OTG_FILE_PART_SIZE))
            val partSizeRep = ByteBuffer.wrap(readReply(8)).order(ByteOrder.LITTLE_ENDIAN)
            val partRes = partSizeRep.getInt(4)
            if (partRes != 0) {
                onLog("هشدار: کد پاسخ تنظیم اندازه بسته = $partRes (ادامه با 128KB)")
            }
        }

        // 2. Send Total Bytes (0x64, 0x02)
        val totalLo = (totalUncompressedBytes and 0xFFFFFFFFL).toInt()
        val totalHi = (totalUncompressedBytes ushr 32).toInt()
        writeAll(buildCmd(CMD_SESSION, SESSION_TOTAL_BYTES, totalLo, totalHi))
        readReply(8)

        var totalSent = 0L
        val plannedBySlot = plan.groupBy { it.slot.slotKey }

        // 3. Stream every selected slot sequentially in Samsung order (BL -> AP -> CP -> CSC)
        for (slot in slots) {
            val slotPlan = plannedBySlot[slot.slotKey] ?: continue
            val wantedNames = slotPlan.associateBy { it.memberName }
            val lower = slot.fileName.lowercase()
            val isTar = lower.endsWith(".tar") || lower.endsWith(".tar.md5")

            resolver.openInputStream(slot.uri)?.use { rawIn ->
                val input = BufferedInputStream(rawIn, 256 * 1024)
                if (isTar) {
                    val header = ByteArray(TAR_BLOCK)
                    while (true) {
                        val read = readFully(input, header, TAR_BLOCK)
                        if (read < TAR_BLOCK || header.all { it.toInt() == 0 }) break
                        val memberName = readCString(header, 0, 100).removePrefix("./")
                        val sizeOct = readCString(header, 124, 12)
                        val memberSize = sizeOct.toLongOrNull(8) ?: 0L
                        val typeFlag = header[156].toInt() and 0xFF
                        if (memberName.isEmpty() || memberSize <= 0L) {
                            if (memberSize > 0L) skipExact(input, memberSize + tarPadding(memberSize))
                            if (memberName.isEmpty()) break else continue
                        }
                        val item = if (typeFlag == 0 || typeFlag == '0'.code) wantedNames[memberName] else null
                        if (item == null) {
                            skipExact(input, memberSize + tarPadding(memberSize))
                            continue
                        }

                        val bounded = BoundedInputStream(input, memberSize)
                        val payloadStream: InputStream = if (item.isLz4) Lz4FrameInputStream(bounded) else bounded
                        val pitEntry = item.pitEntry
                        val label = "[${slot.slotKey}] ${pitEntry.partitionName}"

                        onLog(
                            "فلش ${item.memberName} ← $label (ID=#${pitEntry.partitionId}, DevType=${pitEntry.deviceType}, BinType=${pitEntry.binaryType})..."
                        )
                        flashSinglePartition(
                            input = payloadStream,
                            exactByteSize = item.uncompressedSize,
                            pitEntry = pitEntry,
                            isModemSlot = slot.slotKey == "CP" || pitEntry.binaryType == 1,
                            onLog = onLog
                        ) { added ->
                            totalSent += added
                            onProgress(min(totalSent, totalUncompressedBytes), totalUncompressedBytes, label)
                        }

                        // Ensure any trailing LZ4 footer bytes in this TAR entry are consumed before next TAR header
                        bounded.drainRemaining()
                        val pad = tarPadding(memberSize)
                        if (pad > 0) skipExact(input, pad)
                        onLog("پارتیشن $label با موفقیت نوشته و تایید شد.")
                    }
                } else {
                    val item = slotPlan.first()
                    val payloadStream: InputStream = if (item.isLz4) Lz4FrameInputStream(input) else input
                    val pitEntry = item.pitEntry
                    val label = "[${slot.slotKey}] ${pitEntry.partitionName}"

                    onLog("فلش ایمیج خام ${item.memberName} ← $label (ID=#${pitEntry.partitionId})...")
                    flashSinglePartition(
                        input = payloadStream,
                        exactByteSize = item.uncompressedSize,
                        pitEntry = pitEntry,
                        isModemSlot = slot.slotKey == "CP" || pitEntry.binaryType == 1,
                        onLog = onLog
                    ) { added ->
                        totalSent += added
                        onProgress(min(totalSent, totalUncompressedBytes), totalUncompressedBytes, label)
                    }
                    onLog("پارتیشن $label با موفقیت نوشته و تایید شد.")
                }
            } ?: throw IllegalStateException("امکان باز کردن فایل ${slot.fileName} وجود ندارد.")
        }

        // 4. End Session (0x67, 0x00) + Optional Reboot (0x67, 0x01) — exact Heimdall two-step sequence
        onLog("ارسال دستور پایان نشست Odin (EndSession)...")
        writeAll(buildCmd(CMD_END, END_SESSION))
        readReply(8, timeoutMs = 15000)

        if (autoReboot) {
            onLog("ارسال فرمان راه‌اندازی مجدد گوشی (Auto Reboot)...")
            writeAll(buildCmd(CMD_END, END_REBOOT))
            runCatching { readReply(8, timeoutMs = 10000) }
        }
        onLog("PASS! عملیات فلش با موفقیت کامل شد.")
    }

    /**
     * Exact Heimdall BridgeManager::SendFile wire implementation:
     * - FLASH_START (0x66, 0x00) -> ACK
     * - For each <=30 MiB sequence:
     *   - FLASH_SEQ_START (0x66, 0x02, PADDED_SEQ_BYTES) -> ACK
     *   - For each partIndex in 0 until partCount:
     *       * Read actual bytes, ZERO-PAD remainder up to exact OTG_FILE_PART_SIZE (131072 bytes)
     *       * Bulk OUT exact 131072 bytes
     *       * Bulk IN 8-byte ACK and verify partIndex
     *   - FLASH_SEQ_END (0x66, 0x03) with UNPADDED effectiveByteCount, unknown1=0, pitEntry.deviceType,
     *     partitionId (Phone) or isLast (Modem) -> wait up to 120s for eMMC/UFS write ACK!
     */
    private fun flashSinglePartition(
        input: InputStream,
        exactByteSize: Long,
        pitEntry: PitEntry,
        isModemSlot: Boolean,
        onLog: (String) -> Unit,
        onBytesSent: (Long) -> Unit
    ) {
        writeAll(buildCmd(CMD_FLASH, FLASH_START))
        readReply(8, timeoutMs = 15000)

        val partSize = OTG_FILE_PART_SIZE
        val maxSeqBytes = SEQUENCE_MAX_PARTS.toLong() * partSize.toLong()
        var remaining = exactByteSize
        val partBuf = ByteArray(partSize)

        while (remaining > 0L) {
            val effectiveSeqBytes = min(maxSeqBytes, remaining).toInt()
            val isLastSequence = (remaining - effectiveSeqBytes) <= 0L
            val partCount = ceil(effectiveSeqBytes.toDouble() / partSize.toDouble()).toInt()
            val paddedSeqBytes = partCount * partSize

            // CRITICAL: FLASH_SEQ_START MUST receive PADDED sequence byte count (partCount * partSize)
            writeAll(buildCmd(CMD_FLASH, FLASH_SEQ_START, paddedSeqBytes))
            readReply(8, timeoutMs = 15000)

            var seqRemaining = effectiveSeqBytes
            for (partIndex in 0 until partCount) {
                val want = min(partSize, seqRemaining)
                // Zero-pad the tail of the final partial chunk so exact 131072 bytes are sent!
                if (want < partSize) {
                    partBuf.fill(0.toByte(), want, partSize)
                }
                val got = readFully(input, partBuf, want)
                if (got != want) {
                    throw IllegalStateException("پایان غیرمنتظره فایل حین خواندن پارتیشن ${pitEntry.partitionName} (خوانده: $got از $want)")
                }

                // Send FULL 131072-byte part packet + verify partIndex ACK (with up to 2 retries on transient stall)
                var partAckOk = false
                for (attempt in 1..3) {
                    writeAll(partBuf, partSize, timeoutMs = 30000)
                    try {
                        val rep = readReply(8, timeoutMs = 30000)
                        val bb = ByteBuffer.wrap(rep).order(ByteOrder.LITTLE_ENDIAN)
                        val repPart = bb.getInt(4)
                        if (repPart == partIndex) {
                            partAckOk = true
                            break
                        } else {
                            onLog("هشدار همگام‌سازی بسته (انتظار $partIndex، دریافت $repPart)...")
                        }
                    } catch (e: Exception) {
                        if (attempt == 3) throw e
                        onLog("تلاش مجدد ارسال بسته #$partIndex...")
                    }
                }
                if (!partAckOk) {
                    throw IllegalStateException("تایید بسته #$partIndex از گوشی دریافت نشد.")
                }

                seqRemaining -= want
                onBytesSent(want.toLong())
            }

            // CRITICAL: Exact Heimdall EndPhoneFileTransferPacket / EndModemFileTransferPacket layout
            val destination = if (isModemSlot) 1 else 0
            val endSeq = ByteBuffer.allocate(PACKET_SIZE).order(ByteOrder.LITTLE_ENDIAN).apply {
                putInt(CMD_FLASH)                 // offset 0: 0x66
                putInt(FLASH_SEQ_END)             // offset 4: 0x03
                putInt(destination)               // offset 8: 0 = Phone, 1 = Modem
                putInt(effectiveSeqBytes)         // offset 12: ACTUAL UNPADDED bytes in this sequence
                putInt(0)                         // offset 16: unknown1 = 0
                putInt(pitEntry.deviceType)       // offset 20: PIT deviceType (e.g. 2=eMMC, 8=UFS)
                if (destination == 0) {
                    putInt(pitEntry.partitionId)  // offset 24: partitionIdentifier
                    putInt(if (isLastSequence) 1 else 0) // offset 28: endOfFile
                } else {
                    putInt(if (isLastSequence) 1 else 0) // offset 24: endOfFile (Modem)
                }
            }.array()

            writeAll(endSeq, PACKET_SIZE, timeoutMs = 30000)
            // CRITICAL: Wait up to 120 seconds while phone commits up to 30 MB to eMMC/UFS!
            readReply(8, timeoutMs = 120000)

            remaining -= effectiveSeqBytes
        }
    }

    private fun matchPit(fileName: String, pit: List<PitEntry>): PitEntry? {
        val clean = fileName.substringAfterLast('/').lowercase()
        if (clean.isEmpty() || clean.endsWith(".pit") || fileName.contains("meta-data/", ignoreCase = true)) {
            return null
        }
        val noLz4 = clean.removeSuffix(".lz4")
        val stem = noLz4.substringBeforeLast('.')

        // 1. Exact flashFilename match (with or without .lz4)
        pit.firstOrNull {
            val pf = it.flashFilename.lowercase()
            pf.isNotEmpty() && (pf == clean || pf == noLz4)
        }?.let { return it }

        // 2. Partition name match
        pit.firstOrNull {
            val pn = it.partitionName.lowercase()
            pn.isNotEmpty() && (pn == stem || pn == noLz4)
        }?.let { return it }

        // 3. Common Samsung aliases (sboot.bin -> BOOTLOADER, modem.bin -> RADIO/MODEM, cm.bin -> CM)
        val alias = when (noLz4) {
            "sboot.bin" -> "bootloader"
            "modem.bin" -> "radio"
            "hidden.img" -> "hidden"
            "cache.img" -> "cache"
            "system.img" -> "system"
            "boot.img" -> "boot"
            "recovery.img" -> "recovery"
            else -> null
        }
        if (alias != null) {
            pit.firstOrNull { it.partitionName.equals(alias, ignoreCase = true) }?.let { return it }
        }
        return null
    }

    private fun tarPadding(size: Long): Long {
        val rem = size % TAR_BLOCK
        return if (rem == 0L) 0L else TAR_BLOCK - rem
    }

    private fun readFully(input: InputStream, buf: ByteArray, len: Int): Int {
        var off = 0
        while (off < len) {
            val r = input.read(buf, off, len - off)
            if (r < 0) break
            off += r
        }
        return off
    }

    private fun skipExact(input: InputStream, count: Long) {
        var left = count
        val discard = ByteArray(16384)
        while (left > 0L) {
            val s = input.skip(left)
            if (s <= 0L) {
                val r = input.read(discard, 0, min(discard.size.toLong(), left).toInt())
                if (r < 0) break
                left -= r
            } else {
                left -= s
            }
        }
    }
}
