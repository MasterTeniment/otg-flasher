package com.flashodin.app.protocol

import android.content.ContentResolver
import android.net.Uri
import com.flashodin.app.usb.UsbBinding
import java.io.BufferedInputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.ceil
import kotlin.math.min

data class PitEntry(
    val binaryType: Int,
    val deviceType: Int,
    val partitionId: Int,
    val blockCount: Int,
    val partitionName: String,
    val flashFilename: String
)

data class OdinHandshakeInfo(
    val protocolVersion: Int,
    val maxPacketSize: Int
)

class OdinProtocol(private val binding: UsbBinding) {
    companion object {
        private const val PACKET_SIZE = 1024
        private const val CMD_SESSION = 0x64
        private const val CMD_PIT = 0x65
        private const val CMD_FLASH = 0x66
        private const val CMD_END = 0x67

        private const val SESSION_BEGIN = 0x00
        private const val SESSION_TOTAL_BYTES = 0x02
        private const val SESSION_FILE_PART_SIZE = 0x05

        private const val PIT_DUMP_REQ = 0x01
        private const val PIT_DUMP_PART = 0x02
        private const val PIT_DUMP_END = 0x03

        private const val FLASH_START = 0x00
        private const val FLASH_SEQ_START = 0x02
        private const val FLASH_SEQ_END = 0x03

        private const val PIT_MAGIC = 0x12349876
        private const val TAR_BLOCK = 512
    }

    private fun buildCmd(cmd: Int, sub: Int, a1: Int = 0, a2: Int = 0, a3: Int = 0): ByteArray {
        val buf = ByteBuffer.allocate(PACKET_SIZE).order(ByteOrder.LITTLE_ENDIAN)
        buf.putInt(cmd)
        buf.putInt(sub)
        buf.putInt(a1)
        buf.putInt(a2)
        buf.putInt(a3)
        return buf.array()
    }

    private fun writeAll(data: ByteArray, length: Int = data.size, timeoutMs: Int = 10000) {
        var sent = 0
        while (sent < length) {
            val slice = if (sent == 0 && length == data.size) data else data.copyOfRange(sent, length)
            val written = binding.connection.bulkTransfer(binding.epOut, slice, slice.size, timeoutMs)
            if (written <= 0) {
                throw IllegalStateException("خطا در ارسال داده Bulk OUT (کد: $written)")
            }
            sent += written
        }
    }

    private fun readReply(minLen: Int = 8, timeoutMs: Int = 8000): ByteArray {
        val unit = maxOf(64, binding.epIn.maxPacketSize)
        val reqLen = ceil(maxOf(minLen, unit).toDouble() / unit).toInt() * unit
        val buf = ByteArray(reqLen)
        val read = binding.connection.bulkTransfer(binding.epIn, buf, buf.size, timeoutMs)
        if (read <= 0) {
            throw IllegalStateException("پاسخی از گوشی در Download Mode دریافت نشد (Timeout/کد: $read)")
        }
        return buf.copyOf(read)
    }

    fun handshake(onLog: (String) -> Unit): OdinHandshakeInfo {
        val odinBytes = "ODIN".toByteArray(Charsets.US_ASCII)
        var ok = false
        var lastReply = ""

        for (attempt in 1..3) {
            onLog("ارسال بسته ODIN (تلاش $attempt از ۳)...")
            try {
                writeAll(odinBytes, timeoutMs = 4000)
                val rep = readReply(4, timeoutMs = 4000)
                lastReply = String(rep, Charsets.US_ASCII).trim('\u0000', ' ', '\r', '\n')
                if (lastReply.startsWith("LOKE")) {
                    ok = true
                    break
                }
            } catch (e: Exception) {
                if (attempt == 3) throw e
                Thread.sleep(300)
            }
        }

        if (!ok) {
            throw IllegalStateException("پاسخ LOKE دریافت نشد (پاسخ: \"$lastReply\")")
        }
        onLog("پاسخ LOKE دریافت شد! شروع نشست Odin...")

        writeAll(buildCmd(CMD_SESSION, SESSION_BEGIN, 0x00030000))
        val sessionRep = readReply(8)
        val view = ByteBuffer.wrap(sessionRep).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = view.getInt(0)
        val data = view.getInt(4)
        if (cmd != CMD_SESSION) {
            throw IllegalStateException("خطا در شروع نشست Odin (0x%X)".format(cmd))
        }
        val protoVer = ((data ushr 16) and 0xFFFF).let { if (it >= 3) 3 else 2 }
        val maxPkt = if (protoVer >= 3) 1048576 else 131072
        onLog("نشست Odin v$protoVer.0 فعال شد (حداکثر بسته: ${maxPkt / 1024} KB).")
        return OdinHandshakeInfo(protoVer, maxPkt)
    }

    fun dumpPit(onLog: (String) -> Unit): List<PitEntry> {
        onLog("درخواست خواندن جدول پارتیشن (PIT)...")
        writeAll(buildCmd(CMD_PIT, PIT_DUMP_REQ))
        val sizeRep = ByteBuffer.wrap(readReply(8)).order(ByteOrder.LITTLE_ENDIAN)
        val pitSize = sizeRep.getInt(4)
        if (pitSize <= 28 || pitSize > 1024 * 1024) {
            throw IllegalStateException("اندازه PIT نامعتبر است: $pitSize")
        }

        val pitBytes = ByteArray(pitSize)
        val partSize = 500
        val totalParts = ceil(pitSize.toDouble() / partSize).toInt()

        for (i in 0 until totalParts) {
            writeAll(buildCmd(CMD_PIT, PIT_DUMP_PART, i))
            val remain = pitSize - i * partSize
            val chunk = readReply(min(partSize, remain))
            val copyLen = min(chunk.size, remain)
            System.arraycopy(chunk, 0, pitBytes, i * partSize, copyLen)
        }

        writeAll(buildCmd(CMD_PIT, PIT_DUMP_END))
        readReply(8)

        val entries = parsePit(pitBytes)
        onLog("جدول PIT خوانده شد (${entries.size} پارتیشن).")
        return entries
    }

    private fun parsePit(bytes: ByteArray): List<PitEntry> {
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val magic = bb.getInt(0)
        if (magic != PIT_MAGIC) {
            throw IllegalStateException("امضای باینری PIT نامعتبر است.")
        }
        val count = bb.getInt(4)
        val list = mutableListOf<PitEntry>()
        for (i in 0 until count) {
            val base = 28 + i * 132
            if (base + 132 > bytes.size) break
            val binaryType = bb.getInt(base)
            val deviceType = bb.getInt(base + 4)
            val id = bb.getInt(base + 8)
            val blocks = bb.getInt(base + 24)
            val partName = readCString(bytes, base + 36, 32)
            val flashName = readCString(bytes, base + 68, 32)
            list.add(PitEntry(binaryType, deviceType, id, blocks, partName, flashName))
        }
        return list
    }

    private fun readCString(bytes: ByteArray, offset: Int, maxLen: Int): String {
        var end = offset
        val limit = min(offset + maxLen, bytes.size)
        while (end < limit && bytes[end].toInt() != 0) end++
        return String(bytes, offset, end - offset, Charsets.US_ASCII).trim()
    }

    /**
     * Streams a Samsung .tar / .tar.md5 or raw .img/.bin directly from Android SAF Uri to Odin.
     */
    fun flashUri(
        resolver: ContentResolver,
        uri: Uri,
        fileName: String,
        fileSize: Long,
        pit: List<PitEntry>,
        autoReboot: Boolean,
        onLog: (String) -> Unit,
        onProgress: (sent: Long, total: Long, label: String) -> Unit
    ) {
        val chunkSize = 131072 // 128 KB safe OTG chunk
        writeAll(buildCmd(CMD_SESSION, SESSION_TOTAL_BYTES, (fileSize and 0xFFFFFFFFL).toInt(), (fileSize ushr 32).toInt()))
        readReply(8)
        writeAll(buildCmd(CMD_SESSION, SESSION_FILE_PART_SIZE, chunkSize))
        readReply(8)

        val lower = fileName.lowercase()
        val isTar = lower.endsWith(".tar") || lower.endsWith(".tar.md5")

        resolver.openInputStream(uri)?.use { rawIn ->
            val input = BufferedInputStream(rawIn, 256 * 1024)
            var totalSent = 0L

            if (isTar) {
                val header = ByteArray(TAR_BLOCK)
                while (true) {
                    val read = readFully(input, header, TAR_BLOCK)
                    if (read < TAR_BLOCK || header.all { it.toInt() == 0 }) break
                    val memberName = readCString(header, 0, 100).removePrefix("./")
                    val sizeOct = readCString(header, 124, 12)
                    val memberSize = sizeOct.toLongOrNull(8) ?: 0L
                    if (memberName.isEmpty() || memberSize <= 0L) break

                    val pitMatch = matchPit(memberName, pit)
                    val partId = pitMatch?.partitionId ?: 1
                    val binType = pitMatch?.binaryType ?: 0
                    val partLabel = pitMatch?.partitionName ?: memberName

                    onLog("فلش $memberName ← پارتیشن $partLabel (ID #$partId)...")
                    flashStreamPartition(
                        input = input,
                        size = memberSize,
                        partId = partId,
                        binType = binType,
                        chunkSize = chunkSize
                    ) { added ->
                        totalSent += added
                        onProgress(min(totalSent, fileSize), fileSize, partLabel)
                    }

                    // Skip TAR 512-byte alignment padding
                    val rem = (memberSize % TAR_BLOCK).toInt()
                    if (rem != 0) {
                        skipExact(input, (TAR_BLOCK - rem).toLong())
                    }
                    onLog("پارتیشن $partLabel با موفقیت تایید شد.")
                }
            } else {
                val pitMatch = matchPit(fileName, pit)
                val partId = pitMatch?.partitionId ?: 1
                val binType = pitMatch?.binaryType ?: 0
                val partLabel = pitMatch?.partitionName ?: fileName

                onLog("فلش ایمیج خام $fileName ← $partLabel (ID #$partId)...")
                flashStreamPartition(input, fileSize, partId, binType, chunkSize) { added ->
                    totalSent += added
                    onProgress(min(totalSent, fileSize), fileSize, partLabel)
                }
            }
        } ?: throw IllegalStateException("امکان خواندن فایل انتخاب‌شده وجود ندارد.")

        val endSub = if (autoReboot) 0x01 else 0x00
        onLog(if (autoReboot) "پایان نشست و ارسال دستور Auto Reboot..." else "پایان نشست Odin...")
        writeAll(buildCmd(CMD_END, endSub))
        readReply(8)
        onLog("PASS! عملیات فلش با موفقیت کامل شد.")
    }

    private fun flashStreamPartition(
        input: InputStream,
        size: Long,
        partId: Int,
        binType: Int,
        chunkSize: Int,
        onBytesSent: (Long) -> Unit
    ) {
        writeAll(buildCmd(CMD_FLASH, FLASH_START))
        readReply(8)

        val maxSeq = 30L * 1024L * 1024L
        var remaining = size
        val buf = ByteArray(chunkSize)

        while (remaining > 0L) {
            val seqLen = min(maxSeq, remaining).toInt()
            val isLast = (remaining - seqLen) <= 0L

            writeAll(buildCmd(CMD_FLASH, FLASH_SEQ_START, seqLen))
            readReply(8)

            var seqSent = 0
            while (seqSent < seqLen) {
                val want = min(chunkSize, seqLen - seqSent)
                val got = readFully(input, buf, want)
                if (got <= 0) throw IllegalStateException("پایان غیرمنتظره فایل حین انتقال.")
                writeAll(buf, got)
                readReply(8)
                seqSent += got
                onBytesSent(got.toLong())
            }

            val endSeq = ByteBuffer.allocate(PACKET_SIZE).order(ByteOrder.LITTLE_ENDIAN).apply {
                putInt(CMD_FLASH)
                putInt(FLASH_SEQ_END)
                putInt(binType)
                putInt(seqLen)
                putInt(binType)
                putInt(0)
                putInt(partId)
                putInt(if (isLast) 1 else 0)
            }.array()
            writeAll(endSeq)
            readReply(8)

            remaining -= seqLen
        }
    }

    private fun matchPit(fileName: String, pit: List<PitEntry>): PitEntry? {
        val clean = fileName.substringAfterLast('/').lowercase()
        val noLz4 = clean.removeSuffix(".lz4")
        val stem = noLz4.substringBeforeLast('.')
        return pit.firstOrNull {
            it.flashFilename.equals(clean, ignoreCase = true) ||
                it.flashFilename.equals(noLz4, ignoreCase = true)
        } ?: pit.firstOrNull {
            it.partitionName.equals(stem, ignoreCase = true)
        }
    }

    private fun readFully(input: InputStream, buf: ByteArray, len: Int): Int {
        var off = 0
        while (off < len) {
            val r = input.read(buf, off, len - off)
            if (r < 0) break
            off += r
        }
        return off
    }

    private fun skipExact(input: InputStream, count: Long) {
        var left = count
        while (left > 0) {
            val s = input.skip(left)
            if (s <= 0) {
                if (input.read() < 0) break
                left--
            } else {
                left -= s
            }
        }
    }
}
