# Keep USB and protocol classes intact
-keep class com.flashodin.app.protocol.** { *; }
-keep class com.flashodin.app.usb.** { *; }
