# فلش‌ادین نیتیو (FlashOdin Native Android)

اپلیکیشن نیتیو اندروید (Kotlin + Jetpack Compose) با دسترسی مستقیم سخت‌افزاری `android.hardware.usb.UsbManager` و فیلتر سخت‌افزاری `device_filter.xml` برای فلش موبایل به موبایل از طریق کابل OTG.

## قابلیت‌های تزریق‌شده در هسته نیتیو
- **درایور مستقیم USB OTG (`NativeUsbCore.kt`)**: آزادسازی خودکار درایور کرنل با `claimInterface(iface, true)` و مقداردهی `Samsung CDC-ACM (115200 8N1 + DTR/RTS)`.
- **فیلتر سخت‌افزاری (`res/xml/device_filter.xml`)**: ثبت شناسه سامسونگ (`VID 0x04E8`)، حالت‌های Download Mode، و کلاس‌های استاندارد ADB (`0xFF/0x42/0x01`) و Fastboot (`0xFF/0x42/0x03`) برای باز شدن خودکار برنامه هنگام اتصال کابل.
- **موتور Odin v3 (`OdinProtocol.kt`)**: هندشیک `ODIN/LOKE`، خواندن جدول `PIT` و استریم مستقیم فایل‌های `.tar` / `.tar.md5` / `.img` از حافظه گوشی بدون پر کردن رم.
- **موتور ADB و Fastboot (`AdbProtocol.kt` و `FastbootProtocol.kt`)**: ریبوت مستقیم به `Download Mode` / `Fastboot` / `Recovery`، اجرای دستورات Shell و فلش پارتیشن‌های Fastboot.

---

## ساخت خودکار و رایگان فایل `FlashOdin.apk` با GitHub Actions

بدون نیاز به نصب Android Studio یا کامپیوتر، در ۳ مرحله فایل نصبی APK را بگیرید:

1. یک ریپازیتوری جدید (Public یا Private) در [GitHub](https://github.com/new) بسازید.
2. محتوای فایل ZIP دانلودشده را در ریشه (Root) آن ریپازیتوری آپلود کنید (مطمئن شوید پوشه `.github/workflows/build-android-apk.yml` در ریشه ریپازیتوری باشد).
3. وارد تب **Actions** در ریپازیتوری خود شوید، روی اجرای **Build FlashOdin Native Android APK** کلیک کنید و پس از ~۲ دقیقه از بخش **Artifacts** در پایین صفحه، فایل **FlashOdin-APK** (حاوی `FlashOdin.apk`) را دانلود و روی گوشی خود نصب کنید.
