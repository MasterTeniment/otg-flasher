# OTG FlashTool — Mobile USB Firmware Flasher (v2.0.0)

اپلیکیشن متن‌باز و نیتیو اندروید (Kotlin + Jetpack Compose) برای فلش موبایل به موبایل از طریق کابل OTG — بدون نیاز به کامپیوتر و بدون نیاز به Root.

- **ریپازیتوری رسمی**: [https://github.com/MasterTeniment/otg-flasher](https://github.com/MasterTeniment/otg-flasher)
- **دانلود آخرین نسخه APK**: [https://github.com/MasterTeniment/otg-flasher/releases](https://github.com/MasterTeniment/otg-flasher/releases)

## ویژگی‌های کلیدی نسخه v2.0.0
- **جهت صحیح کابل OTG**: گوشی مبدا (فایل‌ریز) به سر **OTG** وصل می‌شود و گوشی مقصد (دریافت‌کننده) به سر **کابل شارژر** متصل می‌گردد.
- **سازگاری گسترده (`minSdk 21` تا Android 14)**: پشتیبانی از گوشی‌های قدیمی و جدید (از جمله `GT-N7100` با پروتکل v2 و سکانس ایمن ۸ مگابایتی، `SM-G610F` با اصلاح ۱۶ کیلوبایتی USBFS و `CLEAR_HALT`، و `SM-A137F`).
- **پشتیبانی کامل از رام ۴ فایله (`BL / AP / CP / CSC`) + `.lz4` + `ADB` + `Fastboot`**.
- **منطبق با الزامات فنی گوگل پلی**:
  - نام و برندینگ مستقل و توصیفی (`OTG FlashTool`) بدون استفاده از علائم تجاری ثبت‌شده.
  - استفاده انحصاری از **Android USB Host API (`UsbManager`)** بدون نیاز به Root و بدون تغییر در سیستم‌عامل گوشی مبدا.
  - انتخاب فایل صرفاً با **Storage Access Framework (`ACTION_OPEN_DOCUMENT`)** بدون مجوز حساس `MANAGE_EXTERNAL_STORAGE`.
  - دارای **Foreground Service (`dataSync`)** با نوتیفیکیشن پیشرفت و `WakeLock` برای جلوگیری از بسته شدن برنامه حین فلش.
  - دیالوگ اجباری **سلب مسئولیت حرفه‌ای** در اولین اجرا + تب **راهنما** + تب **درباره** با لینک گیت‌هاب.
